package com.mymensa.backend.orders.facade;

/**
 * DTO für die Response nach Bestellungserstellung
 */
public record OrderResponseDTO(
    Integer orderId
) {}
