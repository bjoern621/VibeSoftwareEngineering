package com.rentacar.domain.model;

/**
 * Benutzerrollen für das System.
 */
public enum Role {
    CUSTOMER,
    EMPLOYEE,
    ADMIN
}
