package com.mymensa2.backend.inventory.facade;

public record IngredientUpdateDTO(
    Float stockQuantity
) {}
