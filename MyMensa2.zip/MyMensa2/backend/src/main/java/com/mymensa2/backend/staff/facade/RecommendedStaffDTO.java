package com.mymensa2.backend.staff.facade;

public record RecommendedStaffDTO(
    Integer cooks,
    Integer service,
    Integer total
) {}
