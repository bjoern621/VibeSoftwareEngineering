package com.mymensa2.backend.staff.facade;

public record StaffRequestDTO(
    String firstName,
    String lastName,
    String role
) {}
