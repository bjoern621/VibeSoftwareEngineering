package com.mymensa2.backend.forecasts.facade;

public record CostSavingsDTO(
    Double savedCosts,
    Double potentialSavings
) {}
