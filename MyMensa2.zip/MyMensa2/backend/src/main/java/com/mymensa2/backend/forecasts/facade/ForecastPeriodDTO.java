package com.mymensa2.backend.forecasts.facade;

public record ForecastPeriodDTO(
    String startDate,
    String endDate
) {}
