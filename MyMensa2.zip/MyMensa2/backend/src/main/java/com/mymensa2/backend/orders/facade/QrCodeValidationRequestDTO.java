package com.mymensa2.backend.orders.facade;

public record QrCodeValidationRequestDTO(
    String qrCode
) {}
