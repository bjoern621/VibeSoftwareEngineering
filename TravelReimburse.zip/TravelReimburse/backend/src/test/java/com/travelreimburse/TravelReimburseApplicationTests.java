package com.travelreimburse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelReimburseApplicationTests {

    @Test
    void contextLoads() {
    }

}