package com.travelreimburse.domain.model;

/**
 * Unterstützte Währungen für Reisekosten
 */
public enum Currency {
    EUR,
    USD,
    GBP,
    CHF
}
